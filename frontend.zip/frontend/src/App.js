// App.js

import React, { useEffect, useState, useRef } from "react";
import axios from "axios";

function App() {

  const [search, setSearch] = useState("");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");

  const [products, setProducts] = useState([]);
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);

  const [earnings, setEarnings] = useState(0);
  const [sales, setSales] = useState({});


  useEffect(() => {
    fetchOrders();
  }, []);

  // 📦 FETCH ORDERS
  const fetchOrders = async () => {
    const token = localStorage.getItem("token");
  
    if (!token) return; // ✅ FIX HERE
  
    try {
      const res = await fetch("http://localhost:5000/api/orders/my-orders", {
        headers: {
          Authorization: "Bearer " + token
        },
        cache: "no-store"
      });
  
      const data = await res.json();
      console.log("Fetched Orders:", data);
  
      if (Array.isArray(data)) {
        setOrders(data);
      } else {
        setOrders([]);
      }
  
    } catch (err) {
      console.log(err);
    }
  };

// FETCH EARNINGS
const fetchEarnings = async () => {
  const token = localStorage.getItem("token");
  if (!token) return;

  try {
    const res = await fetch("http://localhost:5000/api/orders/earnings", {
      headers: {
        Authorization: "Bearer " + token
      }
    });

    const data = await res.json();
    setEarnings(data.earnings);

  } catch (err) {
    console.log(err);
  }
};

const fetchSales = async () => {
  const token = localStorage.getItem("token");

  if (!token) return;

  try {
    const res = await fetch("http://localhost:5000/api/orders/sales", {
      headers: {
        Authorization: "Bearer " + token
      }
    });

    const data = await res.json();
    setSales(data);

  } catch (err) {
    console.log(err);
  }
};

const fetchAnalytics = async () => {
  const token = localStorage.getItem("token");

  if (!token) return;

  try {
    const res = await fetch("http://localhost:5000/api/orders/analytics", {
      headers: {
        Authorization: "Bearer " + token
      }
    });

    const data = await res.json();
    setAnalytics(data);

  } catch (err) {
    console.log(err);
  }
};


  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [newName, setNewName] = useState("");
  const [newPrice, setNewPrice] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newImage, setNewImage] = useState("");

  const [loading, setLoading] = useState(true);

  const [newCategory, setNewCategory] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  const [showMenu, setShowMenu] = useState(false);
  const [showCategories, setShowCategories] = useState(false);
  const [showCart, setShowCart] = useState(false);
  const menuRef = useRef();
  const cartRef = useRef();
  const ordersRef = useRef();
  const [showOrders, setShowOrders] = useState(false);
  const [analytics, setAnalytics] = useState({});
  const [shippingCost, setShippingCost] = useState("");

  useEffect(() => {
    fetch("http://localhost:5000/api/products")
      .then(res => res.json())
      .then(data => setProducts(data))
      .catch(err => console.log(err));
  }, []);

  useEffect(() => {
    const token = localStorage.getItem("token");
  
    if (token) {
      fetch("http://localhost:5000/api/auth/me", {
        headers: {
          Authorization: "Bearer " + token
        }
      })
        .then(res => res.json())
        .then(data => {
          if (data.user) {
            setUser(data.user);
          }
          setLoading(false);
        })
        .catch(() => {
          localStorage.removeItem("token");
          setLoading(false);
        });
    } else {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (user) {
      fetchOrders();
  
      if (user.role === "vendor") {
        fetchEarnings();
        fetchSales();
        fetchAnalytics();
      }
    }
  }, [user]);

  useEffect(() => {
    const handleClickOutside = (event) => {
  
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setShowMenu(false);
      }
  
      if (cartRef.current && !cartRef.current.contains(event.target)) {
        setShowCart(false);
      }
  
      if (ordersRef.current && !ordersRef.current.contains(event.target)) {
        setShowOrders(false);
      }
  
    };
  
    document.addEventListener("mousedown", handleClickOutside);
  
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    console.log("Products:", products);
    console.log("User:", user);
     if (user) {
    console.log("LOGGED USER ID:", user._id); 
  }
  }, [products, user]);

  if (loading) {
    return <h2 style={{ textAlign: "center" }}>Loading... ⏳</h2>;
  }

  // 🛒 ADD TO CART
  const addToCart = (product) => {
    const existing = cart.find(i => i._id === product._id);

    if (existing) {
      setCart(cart.map(i =>
        i._id === product._id
          ? { ...i, quantity: i.quantity + 1 }
          : i
      ));
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const increaseQty = (id) => {
    setCart(cart.map(i =>
      i._id === id ? { ...i, quantity: i.quantity + 1 } : i
    ));
  };

  const decreaseQty = (id) => {
    setCart(cart.map(i =>
      i._id === id && i.quantity > 1
        ? { ...i, quantity: i.quantity - 1 }
        : i
    ));
  };

  const removeFromCart = (id) => {
    setCart(cart.filter(i => i._id !== id));
  };

  // 🔐 AUTH
  const handleRegister = async () => {
    const res = await fetch("http://localhost:5000/api/auth/register", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ name, email, password })
    });
    const data = await res.json();
    alert(data.message);
  };

  const handleLogin = async () => {
    const res = await fetch("http://localhost:5000/api/auth/login", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ email, password })
    });
  
    const data = await res.json();
  
    if (data.token) {
      localStorage.setItem("token", data.token);      
      setUser(data.user);  
      alert("Login successful ✅");
      // ✅ ADMIN CHECK ADDED
      if (data.user.email === "admin@gmail.com") {
        setIsAdmin(true);
      }
    
    } else {
      alert(data.message);
    }
  };
  const handleLogout = () => {
    localStorage.removeItem("token");
    setUser(null);
    setCart([]);
    setShowCart(false);
  };

  // 💳 CHECKOUT
  const checkout = async () => {
    try {
      const token = localStorage.getItem("token");
  
      const res = await fetch("http://localhost:5000/api/orders/place-order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + token
        },
        body: JSON.stringify({
          products: cart.map(item => ({
            product: item._id,
            quantity: item.quantity,
          }))
        })
      });
  
      const data = await res.json();
  
      // 🔥 TEMP: simulate payment success
      alert("Payment Successful 💳");
  
      await fetchEarnings();
      await fetchSales();
      fetchOrders();
  
      setCart([]);
      setShowCart(false);
  
    } catch (err) {
      console.log(err);
    }
  };
// ✅ 👉 ADD YOUR FUNCTION HERE (RIGHT BELOW)
const addProduct = async () => {


  const formData = new FormData();

  formData.append("name", newName);
  formData.append("price", newPrice);
  formData.append("description", newDesc);
  formData.append("image", newImage);
  formData.append("category", newCategory);
  formData.append("shippingCost", Number(shippingCost));
  formData.append("userId", user._id); 

  const token = localStorage.getItem("token");

  const res = await fetch("http://localhost:5000/api/products", {
    method: "POST",
    headers: {
      Authorization: "Bearer " + token   
    },
    body: formData
  });

  await res.json();

  alert("Product added ✅");

  const updated = await fetch("http://localhost:5000/api/products");
  const data = await updated.json();
  setProducts(data);

  // refresh products
  fetch("http://localhost:5000/api/products")
    .then(res => res.json())
    .then(data => setProducts(data));
};

const deleteProduct = async (id) => {
  await fetch(`http://localhost:5000/api/products/${id}`, {
    method: "DELETE"
  });

  alert("Product deleted ✅");

  fetch("http://localhost:5000/api/products")
    .then(res => res.json())
    .then(data => setProducts(data));
};

const becomeVendor = async () => {
  const res = await fetch("http://localhost:5000/api/auth/become-vendor", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ userId: user._id })
  });

  // ✅ ADD HERE (THIS IS WHAT YOU ASKED)
  const data = await res.json();
  console.log("STRIPE RESPONSE:", data);

  // 🔥 Redirect to Stripe onboarding
  if (data.url) {
    window.location.href = data.url;
  } else {
    alert("No Stripe URL received ❌");
  }

  setUser({ ...user, role: "vendor" });
};

  const inputStyle = {
    width: "100%",
    padding: "12px",
    marginTop: "10px",
    borderRadius: "10px",
    border: "none",
    outline: "none",
    background: "rgba(255,255,255,0.2)",
    color: "#fff"
  };
  
  console.log("ORDERS:", orders);
  const vendorOrders = orders.filter(o =>
    o.products.some(p => {
      const vendorId =
        typeof p.vendor === "object"
          ? p.vendor._id
          : p.vendor;
  
      return vendorId?.toString() === user?._id?.toString();
    })
  );
  console.log("FILTERED VENDOR ORDERS:", vendorOrders);
  console.log("USER ID:", user?._id);
  return (
    <div style={{
      fontFamily: "Poppins",
      background: "linear-gradient(135deg, #667eea, #764ba2)",
      minHeight: "100vh",
      padding: "20px",
      color: "#fff"
    }}>

{user && (
  <div style={{
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    background: "#fff",
    padding: "10px 20px",
    borderRadius: "10px",
    color: "#333"
  }}>
  

    {/* LEFT */}
    <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
      <h2 style={{ color: "#6c63ff" }}>
        Mini Multi Vendor
      </h2>

      <button
  onClick={() => setShowCategories(!showCategories)}
  style={{
    fontSize: "20px",
    background: "none",
    border: "none",
    cursor: "pointer"
  }}
>
  ☰ Categories
</button>

{showCategories && (
  <div style={{
    position: "absolute",
    top: "40px",
    left: "0",
    background: "#fff",
    color: "#333",
    padding: "10px",
    borderRadius: "8px",
    boxShadow: "0 0 10px rgba(0,0,0,0.2)"
  }}>
    <p onClick={() => {
      setSelectedCategory("All");
      setShowCategories(false);
    }}>All</p>

    <p onClick={() => {
      setSelectedCategory("EV");
      setShowCategories(false);
    }}>EV</p>

    <p onClick={() => {
      setSelectedCategory("Charger");
      setShowCategories(false);
    }}>Charger</p>

    <p onClick={() => {
      setSelectedCategory("Accessory");
      setShowCategories(false);
    }}>Accessory</p>
  </div>
)}
    </div>

    {/* SEARCH */}
    <input
      placeholder="Search products..."
      value={search}
      onChange={(e) => setSearch(e.target.value)}
      style={{
        padding: "8px",
        width: "300px",
        borderRadius: "20px",
        border: "1px solid #ccc"
      }}
    />

    {/* RIGHT */}
    <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>

      {/* PROFILE */}
      <div style={{ position: "relative" }}>
        <button onClick={() => setShowMenu(!showMenu)}>
          👤
        </button>

        {showMenu && (
          <div
          ref={menuRef}  
          style={{
            position: "absolute",
            top: "30px",
            right: "0",
            background: "#fff",
            color: "#333",
            borderRadius: "8px",
            padding: "10px",
            boxShadow: "0 0 10px rgba(0,0,0,0.2)"
          }}
        >
            <p 
  onClick={() => setShowOrders(!showOrders)} 
  style={{ cursor: "pointer" }}
>
  📦 Orders
</p>

{showOrders && (
  <div
    ref={ordersRef}
    onClick={(e) => e.stopPropagation()}
    style={{
      position: "absolute",
      top: "80px",
      right: "20px",
      width: "300px",
      background: "#fff",
      color: "#333",
      padding: "15px",
      borderRadius: "10px",
      boxShadow: "0 0 10px rgba(0,0,0,0.2)",
      zIndex: 1000
    }}
  >
    {user?.role === "vendor" ? (
  <>
    <h3>📦 Orders (Vendor)</h3>
    <div style={{
  background: "#f9f9f9",
  padding: "10px",
  borderRadius: "8px",
  marginBottom: "10px"
}}>
  <h4>📊 Analytics</h4>

  {Object.keys(analytics).length === 0 ? (
    <p>No analytics yet 😔</p>
  ) : (
    Object.keys(analytics).map((key, index) => (
      <div key={index}>
        <p><strong>{key}</strong></p>
        <p>Sold: {analytics[key].quantity}</p>
        <p>Product Price: ₹{analytics[key].productRevenue}</p>
        <p>Shipping: ₹{analytics[key].shippingRevenue}</p>
        <p>Total Revenue: ₹{analytics[key].revenue}</p>
      </div>
    ))
  )}
</div>

    {vendorOrders.length === 0 ? (
      <p>No orders yet 😔</p>
    ) : (
      vendorOrders.map((o, i) => (
        <div key={i} style={{
          borderBottom: "1px solid #ddd",
          marginBottom: "10px",
          paddingBottom: "10px"
        }}>
          <p><strong>Total: ₹{o.totalAmount}</strong></p>

          {/* ✅ STATUS DROPDOWN */}
          <select
            value={o.status}
            onChange={async (e) => {
              const token = localStorage.getItem("token");

              await fetch(`http://localhost:5000/api/orders/status/${o._id}`, {
                method: "PUT",
                headers: {
                  "Content-Type": "application/json",
                  Authorization: "Bearer " + token
                },
                body: JSON.stringify({ status: e.target.value })
              });

              fetchOrders(); // refresh
            }}
          >
            <option>Pending</option>
            <option>Shipped</option>
            <option>Delivered</option>
          </select>

          <small>{new Date(o.createdAt).toLocaleString()}</small>

          {o.products.map((p, index) => (
            <p key={index}>
              {p.product?.name} — ₹{p.price} × {p.quantity} + 🚚 ₹{p.shippingCost || 0}
            </p>
          ))}
        </div>
      ))
    )}
  </>
) : (
  <>
    <h3>📦 Orders</h3>

    {orders && orders.length === 0 ? (
  <p>No orders yet 😕</p>
) : (
  orders.map((o, i) => (
        <div key={i} style={{
          borderBottom: "1px solid #ddd",
          marginBottom: "10px",
          paddingBottom: "10px"
        }}>
          <p><strong>Total: ₹{o.totalAmount}</strong></p>
          <p>
  Status: 
  <span style={{
    color:
      o.status === "Pending" ? "orange" :
      o.status === "Shipped" ? "blue" :
      "green",
    fontWeight: "bold"
  }}>
    {o.status}
  </span>
</p>
          <small>{new Date(o.createdAt).toLocaleString()}</small>

          {o.products.map((p, index) => (
  <p key={index}>
    {p.product?.name} — ₹{p.price} × {p.quantity} + 🚚 ₹{p.shippingCost || 0}
  </p>
))}
        </div>
      ))
    )}
  </>
)}
  </div>
)}
            <p onClick={handleLogout} style={{ color: "red", cursor: "pointer" }}>
              Logout
            </p>
          </div>
        )}
      </div>

      {/* CART */}
      <div style={{ position: "relative" }}>
      {user.role === "customer" && (
  <button onClick={() => setShowCart(!showCart)}>
    🛍️ {cart.length}
  </button>
)}

  {showCart && (
    <div
    ref={cartRef}
    onClick={(e) => e.stopPropagation()}
    style={{
      position: "absolute",
      top: "30px",
      right: "0",
      background: "#fff",
      color: "#333",
      borderRadius: "8px",
      padding: "10px",
      width: "250px",
      boxShadow: "0 0 10px rgba(0,0,0,0.2)"
    }}>
      
      <h4>🛍️ Cart</h4>

      {cart.length === 0 ? (
        <p>Empty 😔</p>
      ) : (
        cart.map(item => (
          <div key={item._id} style={{
            display: "flex",
            justifyContent: "space-between",
            marginBottom: "8px"
          }}>
            <span>{item.name} × {item.quantity}</span>

            <div>
            <button onClick={(e)=>{
  e.stopPropagation();
  decreaseQty(item._id);
}}>➖</button>

<button onClick={(e)=>{
  e.stopPropagation();
  increaseQty(item._id);
}}>➕</button>

<button onClick={(e)=>{
  e.stopPropagation();
  removeFromCart(item._id);
}}>❌</button>
            </div>
          </div>
        ))
      )}

      <hr />

      <h4>
      ₹{cart.reduce(
  (t, i) => t + (i.price * i.quantity) + Number(i.shippingCost || 0),
  0
)}
      </h4>

      
      <button 
  onClick={async () => {
    alert("Processing Order...");

    await checkout(); // ✅ USE THIS ONLY

  }}
>
  Place Order 🛍️
</button>
    </div>
  )}
</div>

    </div>
  </div>
)}
      {!user ? (
      // 🌟 BEAUTIFUL LOGIN UI
      <div style={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        height: "80vh"
      }}>
        <div style={{
          background: "rgba(255, 255, 255, 0.15)",
          backdropFilter: "blur(15px)",
          padding: "30px",
          borderRadius: "20px",
          width: "320px",
          textAlign: "center",
          boxShadow: "0 8px 32px rgba(0,0,0,0.2)",
          border: "1px solid rgba(255,255,255,0.2)"
        }}>

          <h2> Welcome to Multi-Vendor Marketplace</h2>
          <p style={{ color: "#eee" }}>
            Login or create your account
          </p>

          <input
            placeholder="👤 Name"
            onChange={e=>setName(e.target.value)}
            style={inputStyle}
          />

          <input
            placeholder="📧 Email"
            onChange={e=>setEmail(e.target.value)}
            style={inputStyle}
          />

          <input
            type="password"
            placeholder="🔒 Password"
            onChange={e=>setPassword(e.target.value)}
            style={inputStyle}
          />

          <button onClick={handleLogin} style={{
            width: "100%",
            padding: "10px",
            marginTop: "15px",
            background: "linear-gradient(45deg, #6c63ff, #4834d4)",
            color: "#fff",
            border: "none",
            borderRadius: "10px",
            fontWeight: "bold"
          }}>
            Login 
          </button>

          <button onClick={handleRegister} style={{
            width: "100%",
            padding: "10px",
            marginTop: "10px",
            background: "#00b894",
            color: "#fff",
            border: "none",
            borderRadius: "10px",
            fontWeight: "bold"
          }}>
            Register 
          </button>

        </div>
      </div>
      ) : (
        <>

          <h3>Welcome {user.name} 👋</h3>

          {user.role === "vendor" && (
          <h3 style={{ marginTop: "10px" }}>
          💰 Earnings: ₹{earnings}
          </h3>
          )}
          
            {user.role === "customer" && (
            <button 
            onClick={becomeVendor}
            style={{
              background: "#ffa502",
              color: "#fff",
              padding: "8px",
              border: "none",
              borderRadius: "6px",
              marginTop: "10px"
            }}
            >
    Become Vendor 🧑‍💼
  </button>

            
)}
          {(isAdmin  || user.role === "vendor") && (
            <div style={{
              background: "#fff",
              color: "#333",
              padding: "20px",
              borderRadius: "10px",
              marginTop: "20px"
            }}>
              <h3>➕ Add Product </h3>

              <input placeholder="Name" onChange={e => setNewName(e.target.value)} /><br/>
              <input placeholder="Price" onChange={e => setNewPrice(e.target.value)} /><br/>
              <input placeholder="Description" onChange={e => setNewDesc(e.target.value)} /><br/>
              <input placeholder="Category (EV, Charger, Accessory)" onChange={(e) => setNewCategory(e.target.value)}/>
              <input placeholder="Shipping Cost" value={shippingCost} onChange={(e) => setShippingCost(e.target.value)}/>
              <input type="file" onChange={(e) => setNewImage(e.target.files[0])} />
              <button onClick={addProduct}>Add Product</button>
            </div>
          )}
          
          {/* PRODUCTS */}

          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(220px, 250px))",
            justifyContent: "center",
            gap: "20px",
            marginTop: "30px"
          }}>
          
          {products
  .filter(p => {
    if (!p) return false;

    if (user.role === "customer") return true;

    if (user.role === "vendor") {
  if (!p.vendor) return false;

  const vendorId =
    typeof p.vendor === "object"
      ? p.vendor._id
      : p.vendor;

  return vendorId?.toString() === user._id?.toString();
}

    return true;
  })
  .filter(p =>
    p.name?.toLowerCase().includes(search.toLowerCase()) &&
    (minPrice === "" || p.price >= minPrice) &&
    (maxPrice === "" || p.price <= maxPrice) &&
    (selectedCategory === "All" || p.category === selectedCategory)
  )
  .map(p => (
    <div key={p._id} style={{
      background: "#fff",
      color: "#333",
      padding: "15px",
      borderRadius: "12px",
      boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
      textAlign: "center",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between"
    }}>
      <img 
  src={`http://localhost:5000/${p.image}`}  
  alt={p.name} 
  style={{
    width: "100%",
    height: "140px",
    objectFit: "contain",
    marginBottom: "10px"
  }} 
/>
<h4 style={{ fontSize: "16px", margin: "5px 0" }}>
  {p.name}
</h4>

<p style={{ fontWeight: "bold", marginBottom: "10px" }}>
  ₹{p.price}
</p>

<p style={{ fontSize: "13px", color: "#555" }}>
  🚚 Shipping: ₹{p.shippingCost || 0}
</p>

<p style={{
  fontSize: "13px",
  color: "#555",
  marginBottom: "10px"
}}>
  {p.description}
</p>

{user.role === "customer" &&(
<button 
  onClick={() => addToCart(p)}
  style={{
    background: "#6c63ff",
    color: "#fff",
    border: "none",
    padding: "8px",
    borderRadius: "6px",
    cursor: "pointer",
    marginBottom: "5px"
  }}
>
  Add to Cart 🛒
</button>
)}

      {(isAdmin || user.role === "vendor") && (
        <button 
        onClick={() => deleteProduct(p._id)}
        style={{
          background: "red",
          color: "#fff",
          border: "none",
          padding: "6px",
          borderRadius: "6px",
          cursor: "pointer"
        }}
      >
        Delete ❌
      </button>
      )}
    </div>
  ))
}
          </div>
        </>
      )}
    </div>
  );
}

const styles = {
  paymentOverlay: {
    position: "fixed",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
    background: "rgba(0,0,0,0.5)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 1000
  },

  paymentBox: {
    background: "#fff",
    padding: "20px",
    borderRadius: "10px",
    width: "300px",
    textAlign: "center"
  },

  input: {
    width: "90%",
    margin: "10px 0",
    padding: "8px"
  },

  payBtn: {
    background: "green",
    color: "#fff",
    padding: "10px",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer"
  }
};

export default App;